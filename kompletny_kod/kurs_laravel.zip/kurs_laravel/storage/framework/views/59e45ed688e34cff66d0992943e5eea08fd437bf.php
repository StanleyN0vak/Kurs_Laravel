<?php $__env->startSection('content'); ?>
<h2>To jest strona Kontakt</h2>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
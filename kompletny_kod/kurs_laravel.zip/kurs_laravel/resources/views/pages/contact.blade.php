@extends('master')
@section('content')
<h2>To jest strona Kontakt</h2>
@stop
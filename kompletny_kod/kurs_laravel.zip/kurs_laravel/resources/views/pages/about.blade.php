@extends('master')
@section('content')
<h2>To jest strona O nas</h2>
@stop